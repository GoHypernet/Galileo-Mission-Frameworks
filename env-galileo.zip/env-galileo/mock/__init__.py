from __future__ import absolute_import
import mock.mock as _mock
from mock.mock import *
__all__ = _mock.__all__
