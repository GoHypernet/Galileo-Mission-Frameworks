class LogService:
    def __init__(self):
        pass
